
import { GoogleGenAI } from "@google/genai";
import { ChatMessage, ChatSource } from "../types";

const MODEL_NAME = 'gemini-3-flash-preview';

export class GeminiError extends Error {
  constructor(public message: string, public code?: string | number, public status?: string) {
    super(message);
    this.name = 'GeminiError';
  }
}

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  private handleApiError(error: any): never {
    console.error("Gemini API Error Context:", error);

    // Network / Offline Check
    if (!navigator.onLine) {
      throw new GeminiError("No internet connection detected. Please check your network.", "OFFLINE");
    }

    // Attempt to parse stringified JSON error if it comes back as such
    let errorObj = error;
    try {
      if (typeof error?.message === 'string' && error.message.startsWith('{')) {
        errorObj = JSON.parse(error.message);
      }
    } catch (e) {}

    const status = errorObj?.status || errorObj?.error?.status;
    const code = errorObj?.code || errorObj?.error?.code;
    const message = errorObj?.message || errorObj?.error?.message || "An unexpected error occurred.";

    if (code === 429 || status === "RESOURCE_EXHAUSTED") {
      throw new GeminiError("GENTLE AI is currently at capacity (Quota Exceeded). Aditya Chaubey is expanding access. Please wait a moment before trying again.", 429, status);
    }

    if (code >= 500) {
      throw new GeminiError("The AI server encountered a technical hiccup. Please try re-sending your message.", code, status);
    }

    if (message.includes("xhr error") || message.includes("Network error")) {
      throw new GeminiError("Communication with the AI server was interrupted. This is usually a temporary network issue.", "NETWORK_ERROR");
    }

    throw new GeminiError(message, code, status);
  }

  async sendMessage(history: ChatMessage[], message: string, imageBase64?: string) {
    try {
      const contents = history.map(msg => ({
        role: msg.role === 'user' ? 'user' : 'model',
        parts: [{ text: msg.text }]
      }));

      const parts: any[] = [{ text: message }];
      
      if (imageBase64) {
        const base64Data = imageBase64.includes(',') ? imageBase64.split(',')[1] : imageBase64;
        parts.push({
          inlineData: {
            mimeType: 'image/jpeg',
            data: base64Data
          }
        });
      }

      contents.push({
        role: 'user',
        parts: parts
      });

      const response = await this.ai.models.generateContent({
        model: MODEL_NAME,
        contents: contents,
        config: {
          systemInstruction: "You are 'GENTLE AI', an advanced AI assistant created and owned by Aditya Chaubey. You have access to real-time information via Google Search. Your goal is to provide accurate, mind-blowing responses. If anyone asks about your owner, creator, or developer, you must proudly state it is Aditya Chaubey. Maintain a very clean, professional, and minimalist personality.",
          temperature: 0.7,
          tools: [{ googleSearch: {} }],
        },
      });

      const text = response.text || "No response";
      const sources: ChatSource[] = [];

      const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (groundingChunks) {
        groundingChunks.forEach((chunk: any) => {
          if (chunk.web && chunk.web.uri) {
            sources.push({
              title: chunk.web.title || chunk.web.uri,
              uri: chunk.web.uri
            });
          }
        });
      }

      const uniqueSources = Array.from(new Map(sources.map(s => [s.uri, s])).values());

      return { text, sources: uniqueSources };
    } catch (error: any) {
      return this.handleApiError(error);
    }
  }

  async generateTitle(message: string) {
    try {
      const response = await this.ai.models.generateContent({
        model: MODEL_NAME,
        contents: [{ role: 'user', parts: [{ text: `Create a short 2-word title for this session based on: "${message.substring(0, 50)}"` }] }],
      });
      return response.text?.replace(/"/g, '').trim() || "New Chat";
    } catch {
      return "New Chat";
    }
  }
}

export const geminiService = new GeminiService();
