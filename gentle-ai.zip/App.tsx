
import React, { useState, useEffect, useRef } from 'react';
import Sidebar from './components/Sidebar';
import ChatMessage from './components/ChatMessage';
import ChatInput from './components/ChatInput';
import { LiveSession } from './components/LiveSession';
import { ChatSession, ChatMessage as ChatMessageType, UserProfile } from './types';
import { geminiService, GeminiError } from './services/geminiService';
import { AlertCircle, Cpu, User, Check, X, Shield, RefreshCw, MoreVertical } from 'lucide-react';

const App: React.FC = () => {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<{message: string, isNetwork: boolean} | null>(null);
  const [isVoiceMode, setIsVoiceMode] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [profile, setProfile] = useState<UserProfile>({ name: 'ADITYA' });
  const [tempName, setTempName] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = (behavior: ScrollBehavior = 'smooth') => {
    messagesEndRef.current?.scrollIntoView({ behavior });
  };

  useEffect(() => {
    const savedSessions = localStorage.getItem('gentle_ai_sessions');
    const savedProfile = localStorage.getItem('gentle_ai_profile');
    
    if (savedSessions) {
      try {
        const parsed = JSON.parse(savedSessions);
        if (Array.isArray(parsed)) {
          setSessions(parsed);
          if (parsed.length > 0 && !currentSessionId) setCurrentSessionId(parsed[0].id);
        }
      } catch (e) {
        console.error("Session load error", e);
      }
    }
    
    if (savedProfile) {
      try {
        const parsed = JSON.parse(savedProfile);
        setProfile(parsed);
      } catch (e) {}
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('gentle_ai_sessions', JSON.stringify(sessions));
  }, [sessions]);

  useEffect(() => {
    localStorage.setItem('gentle_ai_profile', JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    scrollToBottom();
  }, [sessions, currentSessionId, isLoading]);

  const currentSession = sessions.find(s => s.id === currentSessionId);

  const handleNewChat = () => {
    const newSession: ChatSession = {
      id: Date.now().toString(),
      title: 'New Chat',
      messages: [],
      lastUpdated: Date.now()
    };
    setSessions(prev => [newSession, ...prev]);
    setCurrentSessionId(newSession.id);
    setError(null);
    setIsSidebarOpen(false);
  };

  const handleSendMessage = async (text: string, image?: string) => {
    let activeId = currentSessionId;
    if (!activeId) {
      const newId = Date.now().toString();
      const newSession: ChatSession = { id: newId, title: 'New Chat', messages: [], lastUpdated: Date.now() };
      setSessions(prev => [newSession, ...prev]);
      activeId = newId;
      setCurrentSessionId(activeId);
    }

    const userMessage: ChatMessageType = { id: Date.now().toString(), role: 'user', text, timestamp: Date.now(), image };
    setSessions(prev => prev.map(s => s.id === activeId ? { ...s, messages: [...s.messages, userMessage], lastUpdated: Date.now() } : s));

    setIsLoading(true);
    setError(null);

    try {
      const hist = (sessions.find(s => s.id === activeId)?.messages || []).concat(userMessage);
      const result = await geminiService.sendMessage(hist, text, image);
      
      const aiMessage: ChatMessageType = { 
        id: (Date.now() + 1).toString(), 
        role: 'model', 
        text: result.text, 
        timestamp: Date.now(),
        sources: result.sources
      };
      setSessions(prev => prev.map(s => s.id === activeId ? { ...s, messages: [...s.messages, aiMessage], lastUpdated: Date.now() } : s));

      const sess = sessions.find(s => s.id === activeId);
      if (sess && sess.title === 'New Chat') {
        const title = await geminiService.generateTitle(text);
        setSessions(prev => prev.map(s => s.id === activeId ? { ...s, title } : s));
      }
    } catch (err: any) {
      const isNet = err instanceof GeminiError && (err.code === 'OFFLINE' || err.code === 'NETWORK_ERROR');
      setError({ message: err.message || "Failed to communicate with GENTLE AI.", isNetwork: isNet });
    } finally {
      setIsLoading(false);
    }
  };

  const saveProfile = () => {
    if (tempName.trim()) {
      setProfile({ ...profile, name: tempName.trim().toUpperCase() });
      setIsProfileModalOpen(false);
    }
  };

  return (
    <div className="flex h-screen bg-[#020617] text-slate-200 overflow-hidden font-sans relative">
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[45] lg:hidden animate-in fade-in duration-300"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      <Sidebar 
        sessions={sessions}
        currentSessionId={currentSessionId}
        onSelectSession={(id) => {
          setCurrentSessionId(id);
          setIsSidebarOpen(false);
        }}
        onNewChat={handleNewChat}
        onDeleteSession={(id, e) => {
          e.stopPropagation();
          setSessions(prev => prev.filter(s => s.id !== id));
          if (currentSessionId === id) setCurrentSessionId(null);
        }}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      />

      <main className="flex-1 flex flex-col relative bg-[#020617] w-full overflow-hidden">
        {/* Optimized Header Matching Screenshot */}
        <header className="h-28 flex items-center justify-between px-6 lg:px-12 z-40 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-1.5 h-1.5 rounded-full bg-slate-600 self-center mt-1" />
            <div className="flex flex-col">
              <span className="text-2xl font-black tracking-widest text-white uppercase leading-none">GENTLE AI</span>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.25em] mt-2 opacity-60">Unlimited Core</span>
            </div>
          </div>
          
          <div className="flex items-center gap-4 lg:gap-8">
             <button 
              onClick={() => setIsSidebarOpen(true)}
              className="flex flex-col items-center justify-center bg-[#1e293b]/40 rounded-2xl border border-slate-800/30 active:scale-90 transition-all hover:bg-[#1e293b]/60 w-16 h-16"
            >
              <MoreVertical size={22} className="text-slate-400" />
              <span className="text-[8px] uppercase font-black text-slate-500 tracking-[0.1em] mt-1">History</span>
            </button>
            
            <div className="w-px h-12 bg-slate-800/50" />
            
            <div className="flex items-center gap-4">
              <div className="text-right flex flex-col items-end">
                <span className="text-[9px] uppercase font-bold text-slate-500 tracking-widest mb-1 opacity-60">Created By</span>
                <span className="text-base font-black text-blue-500 uppercase tracking-wider leading-none">ADITYA</span>
              </div>
              <button 
                onClick={() => {
                  setTempName(profile.name);
                  setIsProfileModalOpen(true);
                }}
                className="w-14 h-14 rounded-2xl bg-[#1e293b]/30 border border-slate-800/50 flex items-center justify-center text-slate-400 hover:border-blue-500 transition-all shadow-xl"
              >
                <User size={24} />
              </button>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto custom-scrollbar flex flex-col pt-4">
          {(!currentSession || currentSession.messages.length === 0) ? (
            <div className="flex-1 flex flex-col items-center justify-center p-6 text-center animate-in fade-in duration-1000">
              <div className="space-y-6">
                <h2 className="text-3xl font-bold text-slate-500 uppercase tracking-[0.15em]">
                  System by <span className="text-blue-500 font-black">ADITYA CHAUBEY</span>
                </h2>
                <p className="text-slate-600 text-xl font-medium max-w-xl mx-auto opacity-70 leading-relaxed">
                  The most powerful conversational intelligence on your device.
                </p>
              </div>
            </div>
          ) : (
            <div className="max-w-4xl mx-auto w-full">
              {currentSession.messages.map((msg) => (
                <ChatMessage key={msg.id} message={msg} />
              ))}
              {isLoading && (
                <div className="w-full py-10 px-4 flex gap-6 max-w-3xl mx-auto">
                  <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center shrink-0">
                    <Cpu size={20} className="text-blue-500 animate-pulse" />
                  </div>
                  <div className="space-y-3 flex-1">
                    <div className="h-3 w-32 bg-slate-900 rounded-full animate-pulse" />
                    <div className="h-4 w-full bg-slate-900 rounded-full animate-pulse" />
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} className="h-32" />
            </div>
          )}
        </div>

        <ChatInput 
          onSend={handleSendMessage} 
          onVoiceClick={() => setIsVoiceMode(true)}
          isLoading={isLoading} 
        />
        
        <div className="text-[10px] text-slate-800 text-center pb-8 uppercase tracking-[0.5em] font-black opacity-40 shrink-0 select-none">
          GENTLE AI PLATFORM • ADITYA CHAUBEY EDITION
        </div>
      </main>

      {isVoiceMode && <LiveSession onClose={() => setIsVoiceMode(false)} />}

      {/* Profile Modal */}
      {isProfileModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/95 backdrop-blur-xl p-4 animate-in fade-in duration-300">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-[3rem] p-10 shadow-2xl">
            <div className="flex justify-between items-start mb-8">
              <div>
                <h3 className="text-2xl font-black text-white tracking-tight uppercase">User Profile</h3>
              </div>
              <button onClick={() => setIsProfileModalOpen(false)} className="text-slate-500 hover:text-white transition-colors bg-white/5 p-2 rounded-full">
                <X size={20} />
              </button>
            </div>
            
            <div className="space-y-8">
              <div>
                <label className="text-[10px] uppercase font-black text-slate-500 tracking-[0.3em] mb-3 block">Display Identity</label>
                <input 
                  type="text" 
                  value={tempName}
                  onChange={(e) => setTempName(e.target.value)}
                  autoFocus
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-6 py-5 text-white outline-none transition-all text-base font-bold"
                  placeholder="Identity Name"
                />
              </div>
              <button 
                onClick={saveProfile}
                className="w-full flex items-center justify-center gap-3 py-5 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl transition-all text-sm font-black uppercase tracking-widest shadow-xl shadow-blue-900/30 active:scale-[0.98]"
              >
                <Check size={20} />
                Update Profile
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
