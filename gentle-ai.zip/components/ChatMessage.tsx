
import React from 'react';
import { User, Cpu, ExternalLink } from 'lucide-react';
import { ChatMessage as ChatMessageType } from '../types';

interface ChatMessageProps {
  message: ChatMessageType;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isUser = message.role === 'user';

  return (
    <div className={`w-full flex py-8 px-4 ${isUser ? 'bg-slate-900/30' : 'bg-transparent'}`}>
      <div className="max-w-3xl mx-auto w-full flex gap-4 lg:gap-6">
        <div className={`w-8 h-8 lg:w-10 lg:h-10 rounded-lg flex items-center justify-center shrink-0 ${
          isUser ? 'bg-indigo-600' : 'bg-blue-500'
        }`}>
          {isUser ? <User size={20} className="text-white" /> : <Cpu size={20} className="text-white" />}
        </div>
        
        <div className="flex-1 space-y-4 overflow-hidden">
          <div className="font-semibold text-slate-400 text-xs uppercase tracking-wider">
            {isUser ? 'You' : 'GENTLE AI'}
          </div>
          
          <div className="text-slate-200 leading-relaxed text-base whitespace-pre-wrap break-words">
            {message.text}
          </div>

          {message.image && (
            <div className="mt-4 rounded-xl overflow-hidden border border-slate-800 max-w-sm">
              <img src={message.image} alt="User upload" className="w-full h-auto" />
            </div>
          )}

          {!isUser && message.sources && message.sources.length > 0 && (
            <div className="mt-6 pt-4 border-t border-slate-900 flex flex-col gap-2">
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Sources & References</span>
              <div className="flex flex-wrap gap-2">
                {message.sources.map((source, idx) => (
                  <a
                    key={idx}
                    href={source.uri}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900/50 hover:bg-slate-800 border border-slate-800 rounded-full text-[11px] text-slate-400 hover:text-white transition-all group"
                  >
                    <span className="truncate max-w-[150px]">{source.title}</span>
                    <ExternalLink size={10} className="text-slate-600 group-hover:text-blue-400" />
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;
