
import React, { useEffect, useRef, useState } from 'react';
import { GoogleGenAI, Modality } from '@google/genai';
import { X, Mic, AlertTriangle, RefreshCcw, Cpu, Shield, User } from 'lucide-react';

interface LiveSessionProps {
  onClose: () => void;
}

export const LiveSession: React.FC<LiveSessionProps> = ({ onClose }) => {
  const [isActive, setIsActive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const sessionRef = useRef<any>(null);

  const initSession = async () => {
    setIsConnecting(true);
    setErrorMessage(null);
    setIsActive(false);

    if (!navigator.onLine) {
      setErrorMessage("System Offline. Check Connection.");
      setIsConnecting(false);
      return;
    }

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      inputAudioContextRef.current = inputAudioContext;
      audioContextRef.current = outputAudioContext;

      if (outputAudioContext.state === 'suspended') {
        await outputAudioContext.resume();
      }

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setIsConnecting(false);
            setIsActive(true);
            setErrorMessage(null);
            
            const source = inputAudioContext.createMediaStreamSource(stream);
            // Smaller buffer size (2048) for lower local latency
            const scriptProcessor = inputAudioContext.createScriptProcessor(2048, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createBlob(inputData);
              sessionPromise.then(session => {
                session.sendRealtimeInput({ media: pcmBlob });
              }).catch(() => {});
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputAudioContext.destination);
          },
          onmessage: async (message) => {
            const audioBase64 = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audioBase64) {
              const ctx = audioContextRef.current;
              if (ctx) {
                if (ctx.state === 'suspended') await ctx.resume();
                
                nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
                const audioBuffer = await decodeAudioData(decode(audioBase64), ctx, 24000, 1);
                const source = ctx.createBufferSource();
                source.buffer = audioBuffer;
                source.connect(ctx.destination);
                source.start(nextStartTimeRef.current);
                nextStartTimeRef.current += audioBuffer.duration;
                sourcesRef.current.add(source);
                source.onended = () => sourcesRef.current.delete(source);
              }
            }
            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => { try { s.stop(); } catch(e) {} });
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onclose: (e) => {
            setIsActive(false);
            if (!e.wasClean) setErrorMessage("Connection reset.");
          },
          onerror: (e: any) => {
            console.error("Live Error:", e);
            setIsConnecting(false);
            setErrorMessage("Voice Link Error.");
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } } },
          systemInstruction: "You are GENTLE AI. Be extremely snappy, fast, and concise. Respond instantly as soon as the user stops talking. Your owner is Aditya Chaubey. Never mention you are an AI, be a high-performance human-like voice companion."
        }
      });

      sessionRef.current = await sessionPromise;
    } catch (err: any) {
      setErrorMessage("Mic or Link Failed.");
      setIsConnecting(false);
    }
  };

  useEffect(() => {
    initSession();
    return () => {
      if (sessionRef.current) try { sessionRef.current.close(); } catch(e) {}
      if (audioContextRef.current) audioContextRef.current.close();
      if (inputAudioContextRef.current) inputAudioContextRef.current.close();
      sourcesRef.current.forEach(s => { try { s.stop(); } catch(e) {} });
    };
  }, []);

  function decode(base64: string) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  async function decodeAudioData(data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number) {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  }

  function createBlob(data: Float32Array) {
    const int16 = new Int16Array(data.length);
    for (let i = 0; i < data.length; i++) {
      int16[i] = Math.max(-1, Math.min(1, data[i])) * 32767;
    }
    const bytes = new Uint8Array(int16.buffer);
    let binary = '';
    for (let i = 0; i < bytes.length; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return { data: btoa(binary), mimeType: 'audio/pcm;rate=16000' };
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-[#020617]/95 backdrop-blur-3xl animate-in fade-in duration-500">
      <div className="relative w-full max-w-lg p-6 flex flex-col items-center">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 p-4 text-slate-500 hover:text-white transition-all bg-white/5 rounded-full"
        >
          <X size={24} />
        </button>

        <div className="mb-12 text-center">
          <h2 className="text-3xl font-black text-white mb-2 uppercase tracking-[0.3em]">GENTLE AI</h2>
          <p className="text-blue-500 text-[10px] font-black uppercase tracking-widest">Ultra-Fast Link • Aditya Chaubey</p>
        </div>

        <div className="relative mb-16">
          {isActive && (
            <div className="absolute inset-0">
              <div className="absolute inset-0 bg-blue-500/10 rounded-full animate-ping duration-[2000ms]" />
              <div className="absolute inset-0 bg-blue-600/5 rounded-full animate-pulse scale-150" />
            </div>
          )}
          
          <div className={`w-48 h-48 rounded-full flex items-center justify-center transition-all duration-700 ${isActive ? 'bg-blue-600/10 scale-105 border border-blue-500/30' : 'bg-slate-900 border border-slate-800'}`}>
            {isActive ? (
              <div className="flex items-center gap-2 h-16">
                {[1, 2, 3, 4, 5].map(i => (
                  <div key={i} className="w-2 bg-blue-500 rounded-full animate-wave" style={{ animationDelay: `${i * 0.1}s` }} />
                ))}
              </div>
            ) : (
              <RefreshCcw size={48} className={`text-blue-500 ${isConnecting ? 'animate-spin' : 'opacity-20'}`} />
            )}
          </div>
        </div>

        <div className="flex flex-col items-center gap-6 w-full text-center">
          {errorMessage ? (
            <div className="p-6 bg-red-500/10 border border-red-500/20 rounded-3xl">
              <p className="text-red-400 text-sm font-bold uppercase tracking-widest">{errorMessage}</p>
              <button onClick={initSession} className="mt-4 text-white bg-red-600 px-8 py-3 rounded-xl font-black uppercase text-[10px]">Retry Link</button>
            </div>
          ) : (
            <p className={`font-black tracking-[0.4em] text-sm uppercase ${isActive ? 'text-blue-400' : 'text-slate-700'}`}>
              {isConnecting ? 'Syncing...' : 'System Active'}
            </p>
          )}
        </div>
      </div>
      <style>{`
        @keyframes wave { 0%, 100% { height: 30%; } 50% { height: 100%; } }
        .animate-wave { animation: wave 0.8s infinite ease-in-out; }
      `}</style>
    </div>
  );
};
