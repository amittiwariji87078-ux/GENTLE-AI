
import React, { useState, useRef, useEffect } from 'react';
import { Send, Image as ImageIcon, X, Loader2, Mic } from 'lucide-react';

interface ChatInputProps {
  onSend: (text: string, image?: string) => void;
  onVoiceClick: () => void;
  isLoading: boolean;
}

const ChatInput: React.FC<ChatInputProps> = ({ onSend, onVoiceClick, isLoading }) => {
  const [text, setText] = useState('');
  const [image, setImage] = useState<string | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSend = () => {
    if ((text.trim() || image) && !isLoading) {
      onSend(text.trim(), image || undefined);
      setText('');
      setImage(null);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 150)}px`;
    }
  }, [text]);

  return (
    <div className="w-full bg-transparent pb-8 pt-2 px-6 z-30">
      <div className="max-w-5xl mx-auto relative">
        {image && (
          <div className="absolute bottom-full mb-4 left-4">
            <div className="relative inline-block">
              <img src={image} alt="Upload" className="h-20 w-auto rounded-xl border border-slate-700 shadow-2xl" />
              <button onClick={() => setImage(null)} className="absolute -top-2 -right-2 bg-black text-white p-1 rounded-full border border-slate-800"><X size={12}/></button>
            </div>
          </div>
        )}

        <div className="flex items-center gap-3 bg-[#0a1120] border border-white/5 rounded-[3rem] p-2 pr-4 pl-4 lg:p-2 lg:pr-5 lg:pl-5 transition-all shadow-2xl">
          <button
            onClick={() => fileInputRef.current?.click()}
            className="p-4 text-slate-500 hover:text-blue-400 shrink-0 transition-colors"
            disabled={isLoading}
          >
            <ImageIcon size={22} />
          </button>
          
          <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />

          <textarea
            ref={textareaRef}
            rows={1}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type your prompt..."
            className="flex-1 bg-transparent border-none focus:ring-0 text-slate-200 placeholder-slate-700 py-3 lg:py-4 px-2 resize-none custom-scrollbar text-lg font-medium"
            disabled={isLoading}
          />

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onVoiceClick}
              className="p-4 lg:p-5 text-blue-400 bg-blue-600/15 hover:bg-blue-600/25 rounded-full transition-all active:scale-90 flex items-center justify-center shadow-[0_0_15px_rgba(37,99,235,0.2)]"
              disabled={isLoading}
            >
              <Mic size={24} />
            </button>

            <button
              onClick={handleSend}
              disabled={(!text.trim() && !image) || isLoading}
              className={`p-4 transition-all ${(!text.trim() && !image) || isLoading ? 'text-slate-800' : 'text-slate-400 hover:text-white active:scale-90'}`}
            >
              {isLoading ? <Loader2 size={24} className="animate-spin" /> : <Send size={24} />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatInput;
