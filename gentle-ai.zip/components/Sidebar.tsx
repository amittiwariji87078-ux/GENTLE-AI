
import React from 'react';
import { Plus, MessageSquare, Trash2, ShieldCheck, X } from 'lucide-react';
import { ChatSession } from '../types';

interface SidebarProps {
  sessions: ChatSession[];
  currentSessionId: string | null;
  onSelectSession: (id: string) => void;
  onNewChat: () => void;
  onDeleteSession: (id: string, e: React.MouseEvent) => void;
  isOpen?: boolean;
  onClose?: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  sessions, 
  currentSessionId, 
  onSelectSession, 
  onNewChat,
  onDeleteSession,
  isOpen,
  onClose
}) => {
  return (
    <div className={`
      fixed inset-y-0 left-0 z-[50] w-64 bg-slate-950 border-r border-slate-900 flex flex-col h-full overflow-hidden transition-transform duration-300 ease-in-out lg:relative lg:translate-x-0
      ${isOpen ? 'translate-x-0' : '-translate-x-full'}
    `}>
      <div className="p-4 flex items-center justify-between lg:block">
        <button
          onClick={onNewChat}
          className="flex-1 lg:w-full flex items-center justify-start gap-3 py-2.5 px-4 hover:bg-slate-900 text-slate-300 rounded-lg font-medium transition-all border border-slate-800/50 hover:border-slate-700 active:scale-95"
        >
          <Plus size={18} />
          <span>New Chat</span>
        </button>
        {onClose && (
          <button 
            onClick={onClose}
            className="p-2 ml-2 text-slate-500 hover:text-white lg:hidden"
          >
            <X size={20} />
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto custom-scrollbar px-3 space-y-1">
        {sessions.map((session) => (
          <button
            key={session.id}
            onClick={() => onSelectSession(session.id)}
            className={`w-full group flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all text-left ${
              currentSessionId === session.id
                ? 'bg-slate-900 text-white'
                : 'text-slate-500 hover:bg-slate-900/50 hover:text-slate-300'
            }`}
          >
            <MessageSquare size={14} className="shrink-0" />
            <span className="truncate flex-1">{session.title}</span>
            <Trash2
              size={14}
              className="shrink-0 opacity-0 group-hover:opacity-100 hover:text-red-400 transition-opacity"
              onClick={(e) => onDeleteSession(session.id, e)}
            />
          </button>
        ))}
      </div>

      <div className="p-4 bg-slate-950/50">
        <div className="flex items-center gap-2 px-2 py-2 text-slate-500 text-[10px] uppercase tracking-widest font-bold">
          <ShieldCheck size={12} className="text-emerald-500" />
          <span>Unlimited GENTLE AI</span>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
